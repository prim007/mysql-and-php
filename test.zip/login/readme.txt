*******READ ME******

RAN DATABASE THROUGH MYSQL

USER REGISTRATION
DATABASE NAME
userreg
TABLE Name
usertable

****************************************

cart Name
Product_details

table Name
Product_details
